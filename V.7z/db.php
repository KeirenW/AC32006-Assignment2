<?php
   define('DB_SERVER', 'silva.computing.dundee.ac.uk');
   define('DB_USERNAME', '18ac3u18');
   define('DB_PASSWORD', '111aaa');
   define('DB_DATABASE', '18ac3d18');
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>